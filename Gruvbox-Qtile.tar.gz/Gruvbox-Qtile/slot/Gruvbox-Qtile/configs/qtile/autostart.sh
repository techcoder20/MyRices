#!/usr/bin/env bash 

nitrogen --restore

nm-applet --enable &

picom &
conky &
dunst &
volctl &

